import Letrozole from '../../public/Letrozole.png';
import Estradial from '../../public/ESTRADIAL.png';
import Fertserum from '../../public/Fertserum.png';
import Vitroarg from '../../public/VITROARG.png';
import Image from 'next/image';

const products = [
  {
    id: 1,
    name: 'Letrozole',
    href: '#',
    imageSrc: Letrozole, // Corrected this
    imageAlt: 'Letrozole product image.',
    price: '$35',
    color: 'White',
  },
  {
    id: 2,
    name: 'Estradial',
    href: '#',
    imageSrc: Estradial, // Corrected this
    imageAlt: 'Estradial product image.',
    price: '$40',
    color: 'White',
  },
  {
    id: 3,
    name: 'Fertserum',
    href: '#',
    imageSrc: Fertserum,
    imageAlt: 'Letrozole advanced version image.',
    price: '$45',
    color: 'White',
  },

  {
    id: 4,
    name: 'Vitroarg',
    href: '#',
    imageSrc: Vitroarg,
    imageAlt: 'Letrozole advanced version image.',
    price: '$45',
    color: 'White',
  },
];

export default function Product() {
  return (
    <div id='product' className="bg-white">
      <div className="mx-auto max-w-2xl px-4 py-16 sm:px-6 sm:py-24 lg:max-w-7xl lg:px-8">
        <h2 className="text-2xl font-bold tracking-tight text-gray-900">Our Products</h2>

        <div className="mt-6 grid grid-cols-1 gap-x-6 gap-y-10 sm:grid-cols-2 lg:grid-cols-4 xl:gap-x-8">
          {products.map((product) => (
            <div key={product.id} className="group relative border rounded-lg p-4 shadow hover:shadow-md transition">
              <Image
                alt={product.imageAlt}
                src={product.imageSrc} // Fixed typo here
                className="aspect-square w-full rounded-md bg-gray-200 object-cover group-hover:opacity-75 lg:aspect-auto lg:h-80"
              />
              <div className="mt-4 flex justify-between">
                <div>
                  <h3 className="text-sm text-gray-700 font-semibold">
                    <a href={product.href}>
                      <span aria-hidden="true" className="absolute inset-0" />
                      {product.name}
                    </a>
                  </h3>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
